## A* heuristic optimal path finding on Montreal City Crime dataset


### Requirements
Project workes on Ubuntu 18.04 and Python 3.7.x.
Required libraries are specified in the requirements.txt file

### How to Use

1- Install Python and libraries

2- Change working directory into project directory

3- Type "python3 main.py"
